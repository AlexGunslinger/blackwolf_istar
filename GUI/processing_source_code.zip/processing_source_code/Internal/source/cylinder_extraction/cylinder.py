from copy import deepcopy
from pathlib import Path
import numpy as np
import os
import scipy
import open3d as o3d
import gc

from ..utils.write_output import write_array2txt
from ..utils.data_structures import grid1d
from ..utils.outlier_removal import removal_rail
from ..utils.read_pts import read_input_data
from ..utils.fitting import leastsq_fit_circle
from ..utils.math_methods import rotate_vectors, rotate_around_z
from ..cylinder_extraction.utils import fit_cylinder
from ..cylinder_extraction.config import threshold

class Line():
    def __init__(self, position=None, vector=None):
        self.position = position
        if position is not None:
            self.position = position.reshape((1,3))
        
        self.vector = vector
        if vector is not None:
            self.vector = vector.reshape((1,3))
    
    def intersect_xy(self, z=0):
        # p = position + m x vector
        m = z - self.position[0][-1] / self.vector[0][-1]
        p = self.position + m * self.vector
        return p
    def __repr__(self):
        return str({
            'position': self.position,
            'vector': self.vector
        })
    def transform(self, rotation, translation):
        # self.position = self.position.reshape([3,1])
        # self.position = (rotation@self.position.T) + translation
        # Rx+T: rotation 3x3, translation 3x1
        rotation = rotation.T
        translation = translation.reshape([3,1]).T
        self.position = self.position@rotation + translation
        self.vector = self.vector@rotation

    def distance_to_point(self, p):
        # 2 points that define this line
        a = self.position.squeeze() # A
        b = a + self.vector.squeeze() # B
        # distance = vector_AP x vector AB / |vector_AB|
        d = np.divide(b - a, np.linalg.norm(b - a))
        c = np.cross(p - a, d)
        h = np.linalg.norm(c, axis=1)
        return h

class Cylinder():
    def __init__(self, points=None, radius=None, position=None, vector=None, metadata=None, match=[], **kwargs):
        self.points = points
        self.radius = radius
        self.axis = Line(position, vector)
        self.match = []
        # metadata: station, tank id
        if metadata:
            for key, val in metadata.items():
                setattr(self, key, val)
        for key, val in kwargs.items():
            setattr(self, key, val)
    def __repr__(self):
        return str({
            'station': getattr(self, 'station'),
            'radius': self.radius,
            'axis': self.axis.__repr__(),
            'ptc_filepath': getattr(self, 'ptc_filepath')
        })
    def read_points(self, ptc_col_names=['x', 'y', 'z']):
        p = Path(self.ptc_filepath)
        if p.suffix == '.txt':
            _ = read_input_data(p.parent, p.name)
            src_pts_xyz = _[ptc_col_names].values
            self.points = src_pts_xyz
        elif p.suffix == '.pcd':
            pcd =  o3d.io.read_point_cloud(self.ptc_filepath)
            self.points = np.asarray(pcd.points)
    def write_points(self, sub_dir=None, filename=None, center=False, write_dir=None, data_type='txt'):
        p = Path(self.ptc_filepath)
        if write_dir is None:
            if sub_dir:
                write_dir = str(p.parent / sub_dir)
                if not os.path.exists(write_dir):
                    os.mkdir(write_dir)
            else:
                write_dir = str(p.parent)
        if filename:
            filepath = os.path.join(write_dir, filename)
        else:
            filepath = os.path.join(write_dir, f'{p.stem}.{data_type}')
        # add a center point
        if center:
            z_max = self.points[:,2].max()
            center_top = self.axis.intersect_xy(z=z_max)
            z_min = self.points[:,2].min()
            center_bottom = self.axis.intersect_xy(z=z_min)
            # points = np.r_[self.point, self.axis.position]
            points = np.r_[
                self.points, 
                center_bottom.reshape([1,3]), 
                center_top.reshape([1,3])
            ]
        else:
            points = self.points
        print(f'write to {filepath}: {points.shape} points')
        if data_type == 'txt':
            write_array2txt(filepath, points)
        else:
            pcd = o3d.geometry.PointCloud()
            pcd.points = o3d.utility.Vector3dVector(points)
            # save
            o3d.io.write_point_cloud(
                filepath,
                pcd, print_progress=True
            )
    
    def get_center(self, loc='ground'):
        """
        locates the intersections of this cylinder axis with the plane parallels to Oxy & intersects Oz at given loc
        """
        if isinstance(loc, (int, float)):
            z_center = loc
        elif loc == 'ground':
            z_center = self.station.z_ground
        elif loc == 'min':
            z_center = self.points[:,2].min()
        else:
            # 'max'
            z_center = self.points[:,2].max()
        center = self.axis.intersect_xy(z=z_center)
        return center

    def get_and_write_points(self, write_dir, load_data=False, extend_ground=True, transform=False):
        if load_data:
            self.read_points()
        if extend_ground:
            self.station.read_points()
            self.calc_z_min()
            self.extend_ground()
        if transform:
            self.transform(self.align['rotation'], self.align['translation'], update_axis=False, update_z_min=False)
        self.write_points(center=False, write_dir=write_dir, data_type='pcd')
        # clean up
        del self.station.ptc
        self.station.ptc = None
        del self.points
        self.points = None
        gc.collect()

    def extend_ground(self, extra_radius=1.5, in_place=True):
        # bottom center
        # center = self.axis.intersect_xy()
        # self.read_points()
        # z_min = self.points[:,2].min() + 1
        # center = np.c_[center, z_min]
        # 4m + radius
        # read points from related station
        s = self.station
        if s.ptc is None:
            s.read_points()
        
        # distances to the cylinder axis
        d = self.axis.distance_to_point(s.ptc)
        mask = d <= self.radius + extra_radius

        if in_place:
            self.points = s.ptc[mask,:]
            return self.points
        else:
            return s.ptc[mask,:]

    def update_filepath(self, new_dir=None, num_keep_level=1, file_name=None):
        tails = []
        p = self.ptc_filepath
        for i in range(num_keep_level):
            parts = os.path.split(p)
            tails.insert(0, parts[-1])
            p = parts[0]
        if file_name is not None:
            tails[-1] = file_name
        if new_dir is None:
            new_dir = p
        self.ptc_filepath = os.path.join(new_dir, *tails)
    
    def transform(self, rotation, translation, update_cylinder=True, update_axis=True, update_z_min=True):
        # transform
        if self.points is not None:
            points = self.points.transpose()
            points = (rotation@points) + translation
        
            if update_cylinder:
                self.points = points.transpose()
        if update_axis:
            self.axis.transform(rotation, translation)
        if update_z_min:
            self.z_min = points[2,:].min()

    def make_vertical(self, update_cylinder=True, update_station=True, update_ground=True):
        # rotate the axis vector to vertical directoin
        vector = self.axis.vector.reshape([1,3])
        # to be sure the vector pointing upwward
        if vector[0,2] < 0:
            vector = -vector
        r = rotate_vectors(np.c_[0, 0, 1], vector.T).T
        if update_cylinder:
            self.transform(r, np.zeros([3,1]))
            # center
            if update_ground:
                ground_center = self.get_center(loc='ground')
                # ground_center = ground_center @ r
                ground_center = ground_center @ r.T
                self.station.z_ground = ground_center[0,2]
        # update the alignment matrix for the related station
        if update_station:
            self.station.update_transform(r, np.zeros([3,1]))
    
    def find_ground_z(self, z_scan_max=0, step=0.1):
        points = self.points
        # z_max = points[:,2].max()
        z_min = points[:,2].min()
        cnt = []
        if z_min > z_scan_max:
            # incomplete data at the foot of the tank
            # try to get as much data as possible
            z_scan_max = z_min + 1
        for z in np.arange(z_min, z_scan_max, step):
            # if z % 10 == 0:
            #     print(z)
            ind = (z <= points[:,2]) & (points[:,2] < z + step)
            cnt.append(ind.sum())
        cnt = np.array(cnt)
        diff = np.diff(cnt)
        diff = np.insert(diff, 0, cnt[0])
        # a trick to include the lowest level as a peak
        diff = np.insert(diff, 0, 0)
        # find the left most peak among the top 5 peaks
        peak_indices = scipy.signal.find_peaks(diff)
        peak_indices = peak_indices[0]

        if peak_indices.size > 0:
            i = peak_indices[np.argsort(diff[peak_indices])[-5:]].min() - 1 # -1 to compensate the addition of 0 and cnt[0] above
            self.z_ground = z_min + i * step
        else:
            # not reliable
            self.z_ground = z_scan_max
        return self.z_ground

    def calc_z_min(self):
        self.z_min = self.station.z_ground
        # self.z_min = self.points[:,2].min()

    def translate_base(self, recalc_zmin=True, update_cylinder=True, update_station=True):
        # slide to z_min = 0
        if recalc_zmin:
            self.calc_z_min()
        z_min = self.z_min
        if update_cylinder:
            self.points[:,2] += - z_min
        # update the alignment matrix for the related station
        if update_station:
            self.station.update_transform(np.identity(3), np.r_[0,0,-z_min].reshape([3,1]))
        
    def translate_origin(self, recalc_zmin=True, update_cylinder=True, update_station=True):
        # slide to z_ground
        if recalc_zmin:
            if self.station.ptc is None:
                self.station.read_points()
            self.station.transform(
                self.station.align['rotation'],
                self.station.align['translation']
            )
            self.z_min = self.station.estimate_ground_z()
            # self.calc_z_min()
            # self.z_min = self.find_ground_z()
        if not hasattr(self, 'z_min'):
            print(self)
        z_min = self.z_min
        if update_cylinder:
            self.transform(np.identity(3), np.r_[0,0,-z_min].reshape([3,1]))
        else:
            points = self.points
            points[:,2] -= z_min
        # # update the alignment matrix for the related station
        # if update_station:
        #     self.station.update_transform(np.identity(3), np.r_[0,0,-z_min].reshape([3,1]))
        #     self.z_min = 0
        # xy
        # center = self.axis.intersect_xy()
        center = self.get_center(loc=0)
        if update_cylinder:
            self.transform(np.identity(3), -center.reshape([3,1]))
        else:
            points = points - center.reshape([1,3])
        # update the alignment matrix for the related station
        if update_station:
            translation = np.r_[0,0,-z_min].reshape([3,1])-center.reshape([3,1])
            self.station.update_transform(np.identity(3), translation)
            self.z_min = 0
            if hasattr(self.station, 'ptc'):
                if self.station.ptc is not None:
                    self.station.transform(
                        np.identity(3),
                        translation
                    )

        if update_cylinder:
            return None
        else:
            return points
    
    def rotate_around_z(self, theta, update_station=True):
        self.points = rotate_around_z(self.points, theta)

    def fit(self, refined=False, update=True, ransac_params={}, ignore_number_of_points=False):
        # print(threshold['cylinder_estimation']['min_num_ptc'])
        # to customise parameters
        threshold['cylinder_estimation']['ransac'].update(ransac_params)
        if ignore_number_of_points:
            # use when fitting partial shells
            threshold['cylinder_estimation']['min_num_ptc'] = 1000
        # fit
        res = fit_cylinder(
            self.points,
            threshold
        )
        # get outliers
        outliers_ind = np.delete(
            np.arange(0, self.points.shape[0]),
            res[0],
            axis=0
        )
        outliers_xyz = self.points[outliers_ind,:]
        
        fit_info = dict(zip(
            ['wall_pts_ids', 'wall_pts_xyz', 'voxels', 'cyl_params'],
            res
        ))
        fit_info.update({
            'outliers_ind': outliers_ind,
            'outliers_xyz': outliers_xyz
        })
        if update:
            self.radius = fit_info['cyl_params'][3]
            self.axis = Line(
                position=np.array(fit_info['cyl_params'][:3]).reshape((1,3)),
                vector=np.array(fit_info['cyl_params'][-3:]).reshape((1,3))
            )
        if refined:
            res = fit_cylinder(fit_info['wall_pts_xyz'], threshold)
            # get outliers
            outliers_ind = np.delete(
                np.arange(0, fit_info['wall_pts_xyz'].shape[0]),
                res[0],
                axis=0
            )
            outliers_xyz = fit_info['wall_pts_xyz'][outliers_ind,:]
            fit_info['refined'] = dict(zip(
                ['wall_pts_ids', 'wall_pts_xyz', 'voxels', 'cyl_params'],
                res
            ))
            fit_info['refined'].update({
                'outliers_ind': outliers_ind,
                'outliers_xyz': outliers_xyz
            })
            
            if update:
                self.radius = fit_info['refined']['cyl_params'][3]
                self.axis = Line(
                    position=np.array(fit_info['refined']['cyl_params'][:3]).reshape((1,3)),
                    vector=np.array(fit_info['refined']['cyl_params'][-3:]).reshape((1,3))
                )
        self.ori_axis = deepcopy(self.axis)
        return fit_info

    def quick_fit(self, z_range, z_cuts=[0.4, 0.6, 0.8], thickness=0.01, inlier_max_deviation=0.05):
        height = z_range[1] - z_range[0]
        params = []
        for cut in z_cuts:
            z_cut = z_range[0] + cut * height
            ind = (self.points[:, 2] > z_cut) & (self.points[:, 2] < (z_cut + thickness))
            center_x, center_y, radius, __, __, __ = leastsq_fit_circle(
                self.points[ind, 0],
                self.points[ind, 1],
            )
            params.append([center_x, center_y, z_cut + thickness/2, radius])
        params = np.array(params)
        self.axis = Line(
            position=params[:, :3].mean(axis=0),
            vector=params[-1, :3] - params[0, :3]
        )
        self.radius = params[:,-1].mean()
        # inliers
        # distances to the cylinder axis
        d = self.axis.distance_to_point(self.points)
        self.indices = np.where(np.abs(d - self.radius) <= inlier_max_deviation)[0]

        
    def estimate_top_surface(self, debug=False):
        if self.points is None:
            self.read_points()
        z_min = min(self.points[:,2])
        z_max = max(self.points[:,2])

        self.shell_grids = grid1d(
            self.points, 
            z_min, z_max, 
            0.2, 
            'z'
        )

        # shell grid info
        # x, y, z
        # only use x,y
        # for now, use the xy_intersect center
        # x, y - index 1, 2
        shell_grid_info = np.r_[0, self.axis.intersect_xy()]

        # remove rails
        self.top_surface, self.all_top_ptc_ids = removal_rail(
            self.points, 
            self.shell_grids, shell_grid_info, 
            interval_thickness = 0.2,
            interval_angle = 2*np.pi/180, 
            rail_gap = 0.1#0.025
        )
        # fit circle
        try:
            center_x, center_y, __, __, __, __ = leastsq_fit_circle(
                self.top_surface['ptc'][:,0],
                self.top_surface['ptc'][:,1],
            )
            center_z = np.mean(self.top_surface['ptc'][:,2])
            self.top_surface['center'] = np.array([
                center_x,
                center_y,
                center_z
            ])
            if debug:
                p = self.ptc_filepath
                p = os.path.split(p)[0]
                p = os.path.split(p)[0]
                debug_dir = os.path.join(p, 'debug')
                if not os.path.exists(debug_dir):
                    os.mkdir(debug_dir)
                write_array2txt(
                    os.path.join(debug_dir, f'{self.station.name} {self.id}.txt'),
                    np.r_[self.points, self.top_surface['center'].reshape([1,-1])]
                )
        except Exception:
            print('fit circle failed')

    def build_KDTree(self):
        # open3d to build KDTree
        shell_pcd = o3d.geometry.PointCloud()
        shell_pcd.points = o3d.utility.Vector3dVector(self.points)
        # Build KDTree for this shell
        self.kdtree = o3d.geometry.KDTreeFlann(shell_pcd)
        