# extremely important/sensitive information
# do not publish to github
ACCESS_KEY = 'AKIAIQIE4WPGDWI6IH4A'
SECRET_KEY = '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'
BUCKET_NAME = 'blackwolf-black-box'